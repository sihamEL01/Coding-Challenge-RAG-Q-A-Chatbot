# backend/app/main.py
from dotenv import load_dotenv
load_dotenv()
from fastapi.middleware.cors import CORSMiddleware

from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np
from .embeddings import embed_texts
from .vector_store import load_faiss_index
from .llm import generate_answer

app = FastAPI(title="RAG Q&A")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],   # IMPORTANT (autorise OPTIONS)
    allow_headers=["*"],
)

# Load FAISS index + documents once on startup
index, documents = load_faiss_index()

class QuestionRequest(BaseModel):
    question: str
    top_k: int = 7  # how many chunks to return

@app.post("/ask")
def ask_question(req: QuestionRequest):
    question = req.question
    top_k = req.top_k

    # 1️⃣ Embed the question
    q_emb = embed_texts([question])[0]

    # 2️⃣ Search in FAISS
    distances, indices = index.search(np.array([q_emb]), top_k)
    retrieved_chunks = [documents[i] for i in indices[0]]
    print("\n🔎 Retrieved chunks:")
    for idx in indices[0]:
        print(f"\n--- chunk_{idx} ---")
        print(documents[idx][:500])  # affiche les 500 premiers caractères
        print("\n-------------------\n")
    # 3️⃣ Assemble context
    context = "\n\n".join(retrieved_chunks)

    # 4️⃣ Generate final answer with LLM
    final_answer = generate_answer(question, context)

    return {
        "answer": final_answer,
        "sources": [f"chunk_{i}" for i in indices[0].tolist()]
    }
