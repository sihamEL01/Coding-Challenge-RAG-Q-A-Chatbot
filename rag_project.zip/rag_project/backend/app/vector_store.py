# backend/app/vector_store.py
import faiss
import pickle
import os

INDEX_FILE = "faiss_index.index"
DOCS_FILE = "docs.pkl"


def save_faiss_index(embeddings, documents):
    dim = len(embeddings[0])
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)

    faiss.write_index(index, INDEX_FILE)

    with open(DOCS_FILE, "wb") as f:
        pickle.dump(documents, f)


def load_faiss_index():
    if not os.path.exists(INDEX_FILE) or not os.path.exists(DOCS_FILE):
        raise RuntimeError(
            "FAISS index not found. Please run ingest.py first."
        )

    index = faiss.read_index(INDEX_FILE)

    with open(DOCS_FILE, "rb") as f:
        documents = pickle.load(f)

    return index, documents
